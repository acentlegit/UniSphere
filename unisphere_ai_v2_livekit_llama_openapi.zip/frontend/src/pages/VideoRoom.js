
import { LiveKitRoom } from '@livekit/components-react';

export default function VideoRoom({ token, url }) {
  return (
    <LiveKitRoom serverUrl={url} token={token} connect>
      <h3>Live Classroom</h3>
    </LiveKitRoom>
  );
}
