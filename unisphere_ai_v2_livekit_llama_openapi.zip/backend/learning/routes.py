
from fastapi import APIRouter
from ai.llama_rag import ask

router = APIRouter()

@router.get("/ask")
def ask_topic(q: str):
    return {"answer": ask(q)}
