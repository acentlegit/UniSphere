
from llama_cpp import Llama
from sentence_transformers import SentenceTransformer
import faiss, pickle, os

llm = Llama(model_path="models/llama.gguf")
embedder = SentenceTransformer("all-MiniLM-L6-v2")

INDEX = "index.faiss"
DOCS = "docs.pkl"

if os.path.exists(INDEX):
    index = faiss.read_index(INDEX)
    docs = pickle.load(open(DOCS, "rb"))
else:
    index = faiss.IndexFlatL2(384)
    docs = []

def add_docs(texts):
    emb = embedder.encode(texts)
    index.add(emb)
    docs.extend(texts)
    faiss.write_index(index, INDEX)
    pickle.dump(docs, open(DOCS, "wb"))

def ask(query):
    q_emb = embedder.encode([query])
    _, idx = index.search(q_emb, 5)
    context = "\n".join([docs[i] for i in idx[0] if i < len(docs)])
    prompt = f"Context:\n{context}\nQuestion:{query}"
    output = llm(prompt, max_tokens=512)
    return output["choices"][0]["text"]
