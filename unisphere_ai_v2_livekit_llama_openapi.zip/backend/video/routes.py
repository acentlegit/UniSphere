
from fastapi import APIRouter
import jwt, time

router = APIRouter()
LIVEKIT_API_KEY = "LIVEKIT_API_KEY"
LIVEKIT_SECRET = "LIVEKIT_SECRET"

@router.post("/token")
def generate_token(room: str, user: str):
    payload = {
        "iss": LIVEKIT_API_KEY,
        "sub": user,
        "room": room,
        "exp": int(time.time()) + 3600
    }
    token = jwt.encode(payload, LIVEKIT_SECRET, algorithm="HS256")
    return {"token": token}
