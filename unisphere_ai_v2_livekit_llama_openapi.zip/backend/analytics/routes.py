
from fastapi import APIRouter

router = APIRouter()

@router.get("/dashboard")
def dashboard():
    return {
        "active_users": 180,
        "research_queries": 340,
        "video_sessions": 22
    }
