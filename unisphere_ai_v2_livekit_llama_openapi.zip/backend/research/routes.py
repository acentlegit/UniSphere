
from fastapi import APIRouter
import requests
from ai.llama_rag import add_docs, ask

router = APIRouter()

@router.get("/papers")
def fetch_papers(query: str):
    url = f"https://api.semanticscholar.org/graph/v1/paper/search?query={query}&limit=5"
    res = requests.get(url).json()
    papers = [p["title"] for p in res.get("data", [])]
    add_docs(papers)
    return {"papers": papers}

@router.get("/ask")
def ask_research(q: str):
    return {"answer": ask(q)}
